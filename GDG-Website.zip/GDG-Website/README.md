# GDG on Campus - RIT Hassan website starter

## Run locally
1. Extract this ZIP.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.

## Before publishing
- Verify the official community name and branding requirements with the organizers.
- Add organizer-provided official logos and verified social links.
- Replace the event placeholder with confirmed dates and details.
- Connect a backend or approved form service before collecting real registrations.

The membership form currently displays a demo confirmation; it does not save or send submitted information.
